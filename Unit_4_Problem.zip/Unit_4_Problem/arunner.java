import fileOrganizerlol.code.TheGameItself.game;
/**
 * Partners: Me, Myself, and I
 */
public class arunner {
    private static void run() {
        System.out.println("run");
        game.runGame();
        
    }
    public static void main(String[] args) {
        run();
    }
}